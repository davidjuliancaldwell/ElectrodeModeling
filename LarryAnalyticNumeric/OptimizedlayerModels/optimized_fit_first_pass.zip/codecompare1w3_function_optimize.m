%% initialize workspace
clear all
load('all12.mat')

% define matrices to iterate over
dataTotal_8x8 = [m0b5a2e m702d24 m7dbdec m9ab7ab mc91479 md5cd55 mecb43e];
dataTotal_8x4 = [m2012(1,:)' m2804(1,:)' m2318(1,:)' m2219(1,:)' m2120(1,:)'];
sidVec = {'0b5a2e','702d24','7dbdec','9ab7ab','c91479','d5cd55','ecb43e','m2012','m2804','m2318','m2219','m2120'};
currentMat = [0.00175 0.00075 0.0035 0.00075 0.003 0.0025 0.00175 0.0005 0.0005 0.0005 0.0005 0.0005] ;
stimChansVec = [22 30; 13 14; 11 12; 59 60; 55 56; 54 62; 56 64; 12 20; 4 28; 18 23; 19 22; 21 20];
jp_vec = [3 2 2 8 7 7 7 3 4 3 3 3];
kp_vec = [6 5 3 3 7 6 8 4 4 7 6 5];
jm_vec = [4 2 2 8 7 8 8 2 1 3 3 3];
km_vec = [6 6 4 4 8 6 8 4 4 2 3 4];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define colors for lines

color1 = [27,201,127]/256;
color2 = [190,174,212]/256;
color3 = [ 253,192,134]/256;

% perform optimization for the 1 layer case

h1=0.001;
a=0.00115;
R=0.00115;
d=0.0035;
sigma = 0.05; % this defines for huber loss the transition from squared
% to linear loss behavior

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% optimization for 1 layer
rhoA_vec=[0.1:0.05:3.5];
cost_vec_1layer = zeros(length(sidVec),length(rhoA_vec));

% loop through subjects
for i = 1:length(sidVec)
    
    % select particular values for constants
    i0 = currentMat(i);
    sid = sidVec(i);
    stimChans = stimChansVec(i,:);
    jp = jp_vec(i);
    kp = kp_vec(i);
    jm = jm_vec(i);
    km = km_vec(i);
    
    % perform 1d optimization
    j = 1;
    for rhoA = rhoA_vec
        % extract measured data and calculate theoretical ones
        if i <= 7 % 8x8 cases
            dataMeas = dataTotal_8x8(:,i);
            [l1] = computePotentials_8x8_l1(jp,kp,jm,km,rhoA,i0,stimChans);
            % c91479 was flipped l1 l3
            if strcmp(sid,'c91479')
                l1 = -l1;
            end
            
        else % 8x4 case
            dataMeas = dataTotal_8x4(:,i-7);
            [l1] = computePotentials_8x4_l1(jp,kp,jm,km,rhoA,i0,stimChans);
        end
        
        % use a huber loss functiin
        [h_loss,huber_all] = huber_loss_electrodeModel(dataMeas,l1,sigma);
        cost_vec_1layer(i,j) = h_loss;
        fprintf(['complete for subject ' num2str(i) ' rhoA = ' num2str(rhoA) ' \n ']);
        j = j + 1;
    end
    
end

[~,index_min] = min(cost_vec_1layer,[],2);
subject_min_rho = rhoA_vec(index_min);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 3 layer
% optimization for 3 layer
rho1_vec = [0.4:0.2:1.2];
rho2_vec= [0.4:0.2:6];
rho3_vec = [0.4:0.2:6];
sigma = 0.05; % sigma for huber loss
cost_vec_3layer = zeros(length(sidVec),length(rho1_vec),length(rho2_vec),length(rho3_vec));

subject_min_rho1_vec = zeros(length(rho1_vec),1);
subject_min_rho2_vec = zeros(length(rho2_vec),1);
subject_min_rho3_vec = zeros(length(rho3_vec),1);

for i = 1:length(sidVec)
    
    % select particular values for constants
    i0 = currentMat(i);
    sid = sidVec(i);
    stimChans = stimChansVec(i,:);
    jp = jp_vec(i);
    kp = kp_vec(i);
    jm = jm_vec(i);
    km = km_vec(i);
    
    % perform 3d optimization
    j = 1;
    for rho1 = rho1_vec
        k = 1;
        for rho2 = rho2_vec
            l = 1;
            for rho3 = rho3_vec
                [alpha,beta,eh1,eh2,ed,step,scale] = defineConstants(i0,a,R,rho1,rho2,rho3,d,h1);
                
                if i <= 7 % 8x8 cases
                    dataMeas = dataTotal_8x8(:,i);
                    [l3] = computePotentials_8x8_l3(jp,kp,jm,km,alpha,beta,eh1,eh2,step,ed,scale,a,stimChans);
                    % c91479 was flipped l1 l3
                    if strcmp(sid,'c91479')
                        l3 = -l3;
                    end
                    
                else % 8x4 case
                    dataMeas = dataTotal_8x4(:,i-7);
                    [l3] = computePotentials_8x4_l3(jp,kp,jm,km,alpha,beta,eh1,eh2,step,ed,scale,a,stimChans);
                end
                
                [h_loss,huber_all] = huber_loss_electrodeModel(dataMeas,l3,sigma);
                cost_vec_3layer(i,j,k,l) = h_loss;
                l = l + 1;
                fprintf(['complete for subject ' num2str(i) ' rho1 = ' num2str(rho1) ' rho2 = ' num2str(rho2) ' rho3 = ' num2str(rho3) ' \n' ]);
                
            end
            k = k + 1;
        end
        j = j + 1;
    end
    
end
%
for i = 1:length(sidVec)
    cost_vec_subj = squeeze(cost_vec_3layer(i,:,:,:));
    
    [value, index] = min(cost_vec_subj(:));
    [ind1,ind2,ind3] = ind2sub(size(cost_vec_subj),index);
    
    subject_min_rho1_vec(i) = rho1_vec(ind1);
    subject_min_rho2_vec(i) = rho2_vec(ind2);
    subject_min_rho3_vec(i) = rho3_vec(ind3);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% plotting
% plot

% setup global figure
figTotal = figure('units','normalized','outerposition',[0 0 1 1]);
%
for i = 1:length(sidVec)
    
    fig_ind(i) = figure('units','normalized','outerposition',[0 0 1 1]);
    % select particular values for constants
    i0 = currentMat(i);
    sid = sidVec(i);
    stimChans = stimChansVec(i,:);
    jp = jp_vec(i);
    kp = kp_vec(i);
    jm = jm_vec(i);
    km = km_vec(i);
    rho1 = subject_min_rho1_vec(i);
    rho2 = subject_min_rho2_vec(i);
    rho3 = subject_min_rho3_vec(i);
    
    % perform 1d optimization
    [alpha,beta,eh1,eh2,ed,step,scale] = defineConstants(i0,a,R,rho1,rho2,rho3,d,h1);
    
    % extract measured data and calculate theoretical ones
    if i <= 7 % 8x8 cases
        dataMeas = dataTotal_8x8(:,i);
        [l3] = computePotentials_8x8_l3(jp,kp,jm,km,alpha,beta,eh1,eh2,step,ed,scale,a,stimChans);
        [l1] = computePotentials_8x8_l1(jp,kp,jm,km,subject_min_rho(i),i0,stimChans);
        % c91479 was flipped l1 l3
        if strcmp(sid,'c91479')
            l3 = -l3;
            l1 = -l1;
        end
    else % 8x4 case
        dataMeas = dataTotal_8x4(:,i-7);
        [l3] = computePotentials_8x4_l3(jp,kp,jm,km,alpha,beta,eh1,eh2,step,ed,scale,a,stimChans);
        [l1] = computePotentials_8x4_l1(jp,kp,jm,km,subject_min_rho(i),i0,stimChans);
        
    end
    
    % plot individual subjects
    figure(fig_ind(i));
    plot(dataMeas,'color',color1,'linewidth',2);hold on;
    plot(l1,'color',color2,'linewidth',2);hold on;
    plot(l3,'color',color3,'linewidth',2);hold on;
    xlabel('Electrode Number')
    ylabel('Voltage (\muV)')
    legend('measured','single layer','3 layer');
    dim = [0.2 0.2 0.5 0.5];
    annotation(fig_ind(i), 'textbox', dim, 'String', {['rhoA = ' num2str(subject_min_rho(i))], ['rho1 = ' num2str(subject_min_rho1_vec(i))],['rho2 = ' num2str(subject_min_rho2_vec(i))], ['rho3 = ' num2str(subject_min_rho3_vec(i))]}, 'vert', 'bottom', 'FitBoxToText','on','EdgeColor','none');
    drawnow;
    title(sid)
    OUTPUT_DIR = pwd;
   % SaveFig(OUTPUT_DIR, sprintf(['fit_ind_opt_subject_%s'], char(sid)), 'png', '-r300');
    
    
    % plot them all on one figure with subplots
    figure(figTotal)
    subplot_total(i) = subplot(3,4,i);plot(dataMeas,'color',color1,'linewidth',2);hold on;
    plot(l1,'color',color2,'linewidth',2);hold on;
    subplot(3,4,i);plot(l3,'color',color3,'linewidth',2);hold on;
    title(sid)
end
%
xlabel('Electrode Number')
ylabel('Voltage (\muV)')
legend('measured','single layer','three layer');
%
arrayfun(@(x) pbaspect(x, [1 1 1]), subplot_total);
drawnow;
pos = arrayfun(@plotboxpos, subplot_total, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
for i = 1:12
    annotation(figTotal, 'textbox',  dim{i}, 'String', {['rhoA = ' num2str(subject_min_rho(i))], ['rho1 = ' num2str(subject_min_rho1_vec(i))],['rho2 = ' num2str(subject_min_rho2_vec(i))], ['rho3 = ' num2str(subject_min_rho3_vec(i))]}, 'vert', 'bottom', 'FitBoxToText','on','EdgeColor','none');
end
OUTPUT_DIR = pwd;
%SaveFig(OUTPUT_DIR, ['fit_total_opt'], 'png', '-r300');

%% 3D slice

%subject of interest - 0b5a2e
subject = 1;
param_slice_interest = 2;
cost_vec_subj = squeeze(cost_vec_3layer(subject,:,:,:));

figure
[gridded_x,gridded_y] = meshgrid(rho1_vec,rho2_vec);
surf(gridded_x,gridded_y ,squeeze(cost_vec_subj(:,:, param_slice_interest))')
xlabel('rho1')
ylabel('rho2')


param_slice_interest = 4;
figure
[gridded_x,gridded_y] = meshgrid(rho2_vec,rho3_vec);
surf(gridded_x,gridded_y ,squeeze(cost_vec_subj( param_slice_interest,:,:))')
xlabel('rho2')
ylabel('rho3')

%subject of interest - d5cd55
subject = 1;
param_slice_interest = 5;
cost_vec_subj = squeeze(cost_vec_3layer(subject,:,:,:));

figure
[gridded_x,gridded_y] = meshgrid(rho1_vec,rho2_vec);
surf(gridded_x,gridded_y ,squeeze(cost_vec_subj(:,:, param_slice_interest))')
xlabel('rho1')
ylabel('rho2')


param_slice_interest = 1;
figure
[gridded_x,gridded_y] = meshgrid(rho2_vec,rho3_vec);
surf(gridded_x,gridded_y ,squeeze(cost_vec_subj( param_slice_interest,:,:))')
xlabel('rho2')
ylabel('rho3')
